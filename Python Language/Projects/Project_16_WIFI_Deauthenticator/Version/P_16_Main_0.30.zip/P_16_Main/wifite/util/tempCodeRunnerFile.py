import emoji

A=emoji.emojize(':warning:')
print(A)